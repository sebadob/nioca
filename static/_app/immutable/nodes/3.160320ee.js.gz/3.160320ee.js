import{s}from"../chunks/scheduler.62f7bfe4.js";import{S as t,i as e}from"../chunks/index.4f29d4fa.js";class l extends t{constructor(o){super(),e(this,o,null,null,s,{})}}export{l as component};
